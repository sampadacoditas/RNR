import React from 'react'
import styles from "./Header.module.scss"
export const Header = () => {
  return (
    <header>
        <div className={styles.headerContainer}>
        </div>
    </header>
  )
}
