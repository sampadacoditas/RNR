import React from 'react'

export const TableHeadItem = ({item}:any) => {
  return (
    <th>
      {item.heading}
    </th>
  )
}
