export interface IModal
{
    modal ?:any,
    setModal:any,
    buttonText ?:any,
    Page?:any,
    id?:any
}