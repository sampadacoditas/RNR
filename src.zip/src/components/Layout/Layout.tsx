import React, { useState } from 'react'
import { Login } from '../../pages/Login/Login'
import { Heading } from '../Heading/Heading'

export const Layout = () => {
  return (
    <>
    
    </>
  )
}
