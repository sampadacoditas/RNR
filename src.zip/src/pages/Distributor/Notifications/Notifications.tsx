import React from 'react'
import  style from './Notifications.module.scss' 
export const Notifications = () => {
  return (
    < >
      <div className={style.Notifications}>
      <h1>Here is your Message</h1>
      <span>Your points are decrease by </span>
      </div>
    </>
  )
}
