import React from 'react'

export const Points = () => {
  return (
    <div>Points</div>
  )
}
