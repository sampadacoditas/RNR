export interface ILoginProps
{
    storeEntry:any
    newEntry:object[]
    setNewEntry:({}[])

}