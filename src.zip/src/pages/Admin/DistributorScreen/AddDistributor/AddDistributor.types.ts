export interface IAddDistributor
{
    id?:any,
    modal:boolean,
    toggleModal:()=>void,
    Page:any
}