export interface ICard
{
    id?:any,
    
}