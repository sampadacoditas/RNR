export interface IAdmin
{
    onNavigate:()=>void
}