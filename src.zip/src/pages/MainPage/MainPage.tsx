import React from 'react'
import { Admin } from '../Admin/Admin'
import { Distributor } from '../Distributor/Distributor'
import { Login } from '../Login/Login'

export const MainPage = () => {
  return (
    <>
        {/* <Login/> */}
        {/* <Admin/> */}
        {/* <Distributor/> */}
    </>
  )
}
